1. Mount COMSOL DVD into virtual DVD drive and start installation with setup.exe

2. Select "_SolidSQUAD_\LMCOMSOL_Multiphysics_SSQ.lic" to install COMSOL Multiphysics
   --or--
   Select "_SolidSQUAD_\LMCOMSOL_Server_SSQ.lic" to install COMSOL Server

3. Select Components, Installation folder and options.
   At installation step "Options" untick "Check for updates after installation" and 
   "Enable automatic check for updates"

4. (OPTIONAL) If installing COMSOL Server, UNTICK "Create administrative user" and TICK
   "Windows Authentication"!

   4.1 Run as administrator "COMSOL_Server_Workaround.bat" from "server_install_workaround"
       folder of _SolidSQUAD_ folder

   4.2 Wait until script completes

5. (OPTIONAL) If installing COMSOL Server, after intallation completes, open 
   "http://localhost:2036" in Web browser and login with Windows account name and password

6. Enjoy!

Cracked by TeAM SolidSQUAD-SSQ