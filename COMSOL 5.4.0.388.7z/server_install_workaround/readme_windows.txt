1. Make sure the DVD or folder used to install COMSOL is accessible under same path
   it was during COMSOL Server setup

2. Run as administrator "comsol_Server_Workaround.bat"

3. Wait until script completes

4. Open "http://localhost:2036" and login with your Windows account name and password!

Fixed by TeAM SolidSQUAD-SSQ